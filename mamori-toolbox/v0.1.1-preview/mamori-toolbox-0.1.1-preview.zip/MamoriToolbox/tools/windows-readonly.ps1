﻿#requires -Version 5.1
<#
守りの道具箱 / Windows読み取り専用点検 0.1.0-preview
対象: 管理者が利用を許可したWindows 11クライアント。Windows実機は未検証。
システムの変更、更新、スキャン、外部通信、管理者昇格を行いません。
出力するのは設定の概要だけです。ユーザー名、PC名、IP、回復キーを出力しません。
企業の実行ポリシーにブロックされたら止めてください。回避しないでください。
実行例: powershell.exe -NoProfile -File .\windows-readonly.ps1 -Consent
#>
[CmdletBinding()]
param([switch]$Consent, [string]$OutputDirectory = (Join-Path $PSScriptRoot 'reports'))
$ErrorActionPreference = 'Stop'
if (-not $Consent) {
    Write-Output 'まだ点検していません。利用権限・管理者の承認を確認した場合だけ -Consent を指定してください。'
    return
}
if ($env:OS -ne 'Windows_NT') { throw 'Windows以外では実行しません。' }
$fullOutput = [System.IO.Path]::GetFullPath($OutputDirectory)
if ($fullOutput.StartsWith('\\') -or $fullOutput.StartsWith('//')) { throw 'ネットワーク共有へは保存できません。同期されないローカルの保存先を選んでください。' }
$drive = [System.IO.DriveInfo]::new([System.IO.Path]::GetPathRoot($fullOutput))
if ($drive.DriveType -ne [System.IO.DriveType]::Fixed) { throw '固定のローカルドライブを選んでください。' }
# 既存の出力先または親がリンクなら、意図しない共有先への出力を避けます。
$ancestor = $fullOutput
while ($ancestor) {
    if (Test-Path -LiteralPath $ancestor) {
        $item = Get-Item -LiteralPath $ancestor
        if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'リンク経由の保存先は使えません。通常のローカルフォルダーを選んでください。' }
    }
    $parent = [System.IO.Directory]::GetParent($ancestor)
    if ($null -eq $parent) { break }; $ancestor=$parent.FullName
}
$checks = New-Object 'System.Collections.Generic.List[object]'
function Add-Check([string]$Id,[string]$Title,[string]$Status,[string]$Detail,[string]$Action) {
    $checks.Add([pscustomobject][ordered]@{id=$Id;title=$Title;status=$Status;detail=$Detail;action=$Action})
}
function Unknown-Check([string]$Id,[string]$Title,[string]$Action) {
    Add-Check $Id $Title 'unknown' '権限不足・非対応・情報なし・取得エラー等により未確認です。安全と判定していません。' $Action
}
# 各照会はローカルだけ。失敗の生メッセージ（機器名等を含み得る）は出力しません。
$mp = $null
try { $mp=Get-MpComputerStatus | Select-Object AMRunningMode,AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureAge,IsTamperProtected } catch {}
if ($null -eq $mp) { Unknown-Check 'defender' 'Defenderの保護状態' '既存のウイルス対策・EDR製品の稼働状態を管理者が確認してください。' }
elseif ($mp.AMRunningMode -ne 'Normal') { Add-Check 'defender' 'Defenderの保護状態' 'review' '通常のアクティブモード以外です。第三者の対策製品や組織の構成が関係する可能性があります。' '既存製品の保護状態を管理者が確認してください。Defenderを独断で有効化しないでください。' }
elseif (($mp.RealTimeProtectionEnabled -eq $true) -and ($mp.AntivirusEnabled -eq $true)) { Add-Check 'defender' 'Defenderの保護状態' 'observed' 'AntivirusEnabledとRealTimeProtectionEnabledは有効という応答です。' '設定の確認のみです。感染の有無・EDRの検知運用は別途確認してください。' }
elseif (($mp.RealTimeProtectionEnabled -eq $false) -or ($mp.AntivirusEnabled -eq $false)) { Add-Check 'defender' 'Defenderの保護状態' 'attention' '通常モードですが、ウイルス対策またはリアルタイム保護が無効という応答です。' '管理者が他の保護製品・例外理由を確認してください。自動で設定変更はしません。' }
else { Unknown-Check 'defender' 'Defenderの保護状態' '管理コンソールで保護状態を確認してください。' }
if (($null -ne $mp) -and ($null -ne $mp.AntivirusSignatureAge) -and ([double]$mp.AntivirusSignatureAge -ge 0) -and ([double]$mp.AntivirusSignatureAge -lt 10000)) {
    $age=[int]$mp.AntivirusSignatureAge
    $state=if($age -gt 7){'attention'}else{'observed'}
    Add-Check 'definitions' 'Defenderの検出定義' $state ('定義の経過日数: '+$age+'日。7日はこのツールの見直し目安です。') '既存製品の定義更新を管理者が確認してください。日数だけで最新性や非感染を保証しません。'
} else { Unknown-Check 'definitions' 'Defenderの検出定義' '利用する対策製品の更新状態を確認してください。' }
if (($null -ne $mp) -and ($mp.IsTamperProtected -eq $true)) { Add-Check 'tamper' 'Defenderの改ざん防止' 'observed' 'IsTamperProtectedは有効という応答です。' '組織の管理状態と例外を確認してください。' }
elseif (($null -ne $mp) -and ($mp.IsTamperProtected -eq $false)) { Add-Check 'tamper' 'Defenderの改ざん防止' 'review' 'IsTamperProtectedは無効という応答です。' '既存製品と組織の方針に照らし、必要性を管理者が判断してください。' }
else { Unknown-Check 'tamper' 'Defenderの改ざん防止' 'Defenderまたは既存製品の改ざん防止を管理者が確認してください。' }
try {
    $profiles=@(Get-NetFirewallProfile -PolicyStore ActiveStore | Select-Object Name,Enabled)
    $valid=@($profiles | Where-Object { $_.Name -in @('Domain','Private','Public') })
    if (($valid.Count -ne 3) -or (@($valid.Name | Select-Object -Unique).Count -ne 3)) { throw '取得不足' }
    $off=@($valid | Where-Object { [int]$_.Enabled -eq 0 })
    $unknown=@($valid | Where-Object { [int]$_.Enabled -notin @(0,1) })
    if($unknown.Count -gt 0) { throw '状態不明' }
    $state=if($off.Count -gt 0){'attention'}else{'observed'}
    Add-Check 'firewall' 'Windowsファイアウォール' $state ('有効な構成を照会。無効なプロファイル数: '+$off.Count+' / 3') '例外ルール、境界装置、実際のインターネット到達性は検査していません。管理者が確認してください。'
} catch { Unknown-Check 'firewall' 'Windowsファイアウォール' '各プロファイルと例外ルールを管理者が確認してください。' }
try {
    $v=(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name EnableLUA).EnableLUA
    if($v -notin @(0,1)){throw '状態不明'}
    $state=if($v -eq 1){'observed'}else{'attention'}
    Add-Check 'uac' 'ユーザーアカウント制御' $state ('EnableLUA: '+$v) '通知レベルや日常アカウントの権限は別途確認してください。'
} catch { Unknown-Check 'uac' 'ユーザーアカウント制御' 'UACと日常利用の権限を管理者が確認してください。' }
$rdp=$null
try {
    $rdp=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections).fDenyTSConnections
    if($rdp -notin @(0,1)){throw '状態不明'}
    if($rdp -eq 0){Add-Check 'rdp' 'リモートデスクトップ接続' 'review' '接続を許可する設定です。' '必要性、接続経路、外部公開、認証を管理者が確認してください。許可されているだけで危険とは断定しません。'}
    else{Add-Check 'rdp' 'リモートデスクトップ接続' 'observed' '接続を拒否する設定です。' '別の遠隔操作ソフトや経路は未確認です。'}
} catch { $rdp=$null; Unknown-Check 'rdp' 'リモートデスクトップ接続' '組織のリモート接続の必要性と制限を確認してください。' }
if($rdp -eq 1) { Add-Check 'rdp_nla' 'RDPのネットワークレベル認証' 'na' 'RDPを拒否する設定のため、現時点では対象外です。' 'RDPを有効化する場合は認証方式を再確認してください。' }
else { try {
    $v=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name UserAuthentication).UserAuthentication
    if($v -notin @(0,1)){throw '状態不明'}
    $state=if($v -eq 1){'observed'}else{'attention'}
    Add-Check 'rdp_nla' 'RDPのネットワークレベル認証' $state ('UserAuthentication: '+$v) 'これは多要素認証の確認ではありません。接続経路・MFA・公開範囲は別途確認してください。'
} catch { Unknown-Check 'rdp_nla' 'RDPのネットワークレベル認証' 'RDPの認証設定を管理者が確認してください。' } }
try {
    $s=Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol
    if($null -eq $s.EnableSMB1Protocol){throw '状態不明'}
    $state=if($s.EnableSMB1Protocol -eq $true){'attention'}else{'observed'}
    Add-Check 'smb1_server' 'SMB1サーバー設定' $state ('SMB1サーバー有効: '+$s.EnableSMB1Protocol) 'クライアント側は別項目です。古い装置の依存を調べ、管理者が移行を判断してください。'
} catch { Unknown-Check 'smb1_server' 'SMB1サーバー設定' 'ファイル共有の対応版を管理者が確認してください。' }
try {
    $s=Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol | Select-Object State
    if([string]$s.State -eq 'Enabled'){Add-Check 'smb1_feature' 'SMB1オプション機能' 'attention' 'SMB1ProtocolはEnabledという応答です。' '古い装置・業務との互換性を確認し、管理者が移行を判断してください。'}
    elseif([string]$s.State -in @('Disabled','DisabledWithPayloadRemoved')){Add-Check 'smb1_feature' 'SMB1オプション機能' 'observed' 'SMB1Protocolは無効という応答です。' '新しい共有プロトコル、アクセス権、更新も確認してください。'}
    else{throw '状態不明'}
} catch { Unknown-Check 'smb1_feature' 'SMB1オプション機能' '管理者承認済みの画面・手順で確認してください。取得のために権限昇格は行いません。' }
try {
    $v=Confirm-SecureBootUEFI
    if($v -eq $true){Add-Check 'secure_boot' 'セキュアブート' 'observed' '有効という応答です。' '設定のみの確認です。ファームウェアの最新性は別途確認してください。'}
    elseif($v -eq $false){Add-Check 'secure_boot' 'セキュアブート' 'review' '無効という応答です。' '互換性・回復キーを管理者が確認してから方針を決めてください。'}else{throw '状態不明'}
} catch { Unknown-Check 'secure_boot' 'セキュアブート' '権限・対応状況を管理者が確認してください。未確認を無効と判定しません。' }
try {
    $b=Get-BitLockerVolume -MountPoint $env:SystemDrive | Select-Object ProtectionStatus,VolumeStatus,EncryptionPercentage
    if(($null -eq $b.ProtectionStatus)-or($null -eq $b.EncryptionPercentage)){throw '状態不明'}
    if(([string]$b.ProtectionStatus -eq 'On') -and ([int]$b.EncryptionPercentage -eq 100)) {Add-Check 'bitlocker' 'システムドライブの暗号化' 'observed' '保護On・暗号化100%という応答です。回復キーは出力しません。' '回復キーの安全な保管・復旧手順は管理者が別途確認してください。暗号化はランサムウェア対策の代替ではありません。'}
    else {Add-Check 'bitlocker' 'システムドライブの暗号化' 'review' '保護On・暗号化100%の両方を確認できませんでした。' '管理者が現在の保護状態・一時停止の理由・他製品の暗号化を確認してください。'}
} catch { Unknown-Check 'bitlocker' 'システムドライブの暗号化' '権限・対応エディション・他製品を管理者が確認してください。回復キーはこのツールへ入力しないでください。' }
try {
    $latest=Get-HotFix | Where-Object { $null -ne $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1 -Property InstalledOn
    if($null -eq $latest){throw '履歴なし'}
    $days=((Get-Date)-[datetime]$latest.InstalledOn).TotalDays
    if($days -lt 0){throw '未来日'}
    $detail='取得可能な最新修正履歴から '+[int][math]::Floor($days)+' 日。Get-HotFixは全更新を網羅しません。'
    Add-Check 'update_history' 'Windows更新履歴の目安' 'review' $detail 'Windows Update、OSのサポート期限、アプリと機器の更新を管理者が確認してください。最新パッチ適用済みとは判定しません。'
} catch { Unknown-Check 'update_history' 'Windows更新履歴の目安' 'Windows Updateと管理コンソールで現在の適用状態を確認してください。' }
$result=[ordered]@{schema='mamori.windows/1';version='0.1.0-preview';demo=$false;collectedAt=[datetime]::UtcNow.ToString('o');checks=@($checks.ToArray());limitation='読み取り専用の設定確認です。ウイルス検査、未知の脆弱性検出、外部公開の確認、ネットワーク走査、監視・隔離は行いません。JSONは署名された証跡ではありません。'}
if(-not(Test-Path -LiteralPath $fullOutput)) { [void][System.IO.Directory]::CreateDirectory($fullOutput) }
$name='mamori-windows-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)+'.json'
$path=Join-Path $fullOutput $name
$bytes=([System.Text.UTF8Encoding]::new($false)).GetBytes(($result|ConvertTo-Json -Depth 6))
$stream=[System.IO.FileStream]::new($path,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
Write-Output ('点検結果: '+$path)
Write-Output '同梱のSTART.htmlを開き、Windows点検でJSONを選択してください。結果は社内の情報として管理してください。'

サンプルはすべて架空です。
windows-demo.jsonは実端末の測定値ではありません。
original-example.txtとrestored-same-example.txtは同じバイト列です。
restored-different-example.txtは異なります。照合機能の練習用で、実際のバックアップ・復元を行った証跡ではありません。
